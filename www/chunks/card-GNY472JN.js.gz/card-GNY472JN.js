import{a}from"./chunk-ATV4D7NN.js";import"./chunk-FO2F77I5.js";import"./chunk-KZWUPQG3.js";import"./chunk-KLUKP4ZZ.js";import"./chunk-JRAU7HWG.js";import"./chunk-4YHDLG2C.js";export{a as SimsonCard};
